REPNIVO ANDROID PROJECT — READ FIRST

This is an Android Studio project source package, not a compiled APK.
It wraps the RepNivo HTML prototype in a simple Android WebView app.

BUILD ON A CLOUD RUNNER (phone-friendly route):
1. Sign in to GitHub in your browser and create a new repository named RepNivo.
2. Upload the CONTENTS of this ZIP to the repository (keep the folder structure).
3. Open the repository's Actions tab.
4. If prompted, enable GitHub Actions.
5. The workflow named "Build RepNivo APK" runs on upload. You can also select it and press "Run workflow".
6. Open the completed workflow run, scroll to Artifacts, and download "RepNivo-debug-APK".
7. Extract the downloaded artifact ZIP; it contains app-debug.apk.
8. Open the APK on your Android phone and follow Android's install prompt.

IMPORTANT LIMITATIONS:
- This is an installable debug APK wrapper of the existing browser prototype.
- Repetition counting is manual; there is no camera AI yet.
- The alarm is a prototype and may not fire when the app is closed or the phone sleeps.
- Do not rely on this as a safety-critical alarm.
- A debug APK is for testing, not Play Store release.
